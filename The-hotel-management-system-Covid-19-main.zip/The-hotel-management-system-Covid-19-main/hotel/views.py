from audioop import reverse
from itertools import chain
from multiprocessing import context
from pyexpat import model
from django.shortcuts import render,redirect
from django.http import HttpResponse, HttpResponseRedirect
from django.forms import inlineformset_factory
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.core.cache.backends.base import DEFAULT_TIMEOUT
from django.views.decorators.cache import cache_page
from django.core.cache import cache
from django.views.generic import ListView,FormView
from .models import Room,BookingRoom
from .forms import AvailabilityForm
from .forms import EmployeeForm
from hotel.bookingFunctions.availability import check_availability
# Create your views here.
from .models import * 

CACHE_TTL = getattr(settings,'CACHE_TTL',DEFAULT_TIMEOUT)

from .forms import AvailabilityForm, CreateUserForm
def registerPage(request):
    if request.user.is_authenticated:
        return redirect('deshboard')
    else:
        form = CreateUserForm()
        if request.method =='POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request,'Account was created for ' + user)

                return redirect('login')


        context = {'form':form}
        return render(request,'hotels/Register.html',context)

def loginPage(request):
    if request.user.is_authenticated:
        return redirect('deshboard')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request,username=username,password=password)

            if user is not None:
                login(request,user)
                return redirect('deshboard')
            else:
                messages.info(request,'Username OR Password is incorrect')

        context = {}
        return render(request,'hotels/Login.html',context)


def logoutUser(request):
    logout(request)
    return redirect('login')

#@login_required(login_url='login')
def deshBoard(request):
    context = {}
    return render(request,'hotels/deshboard.html',context)

def get_room(filter_room=None):
    if filter_room:
        print("DATA COMING FROM DB")
        room = Room.objects.filter(category__contains = filter_room)
    else:
        room = Room.objects.all()
    return room


def home(request):
    filter_room = request.GET.get('room')
    if cache.get(filter_room):
        print("DATA COMING FROM CACHE")
        room = cache.get(filter_room)
    else:
        if filter_room:
            room = get_room(filter_room)
            cache.set(filter_room,room)
        else:
            room = get_room()
    context = {'room':room}
    return render(request,'hotels/home.html',context)

#@login_required(login_url='login')
def show(request,id):
    if cache.get(id):
      
        room = cache.get(id)
    else:
        room = Room.objects.get(id=id)
        cache.set(id,room)
    context = {'room':room}
    return render(request,'hotels/show.html',context)

class RoomList(ListView):
    model = Room


class BookingList(ListView):
    model = BookingRoom


class BookingView(FormView):
    form_class = AvailabilityForm    
    template_name = 'availability_form.html'

    def form_valid(self, form):
        data = form.cleaned_data
        room_list = Room.objects.filter(category=data['room_category'])
        available_rooms=[]
        for room in room_list:
            if check_availability(room,data['check_in'],data['check_out']):
                available_rooms.append(room)
        if len(available_rooms)>0:
            room = available_rooms[0]
            bookingroom = BookingRoom.objects.create(
                user = self.request.user,
                room = room,
                check_in = data['check_in'],
                chek_out = data['check_out']
            )
            bookingroom.save()
            return HttpResponse(bookingroom)
        else:
            return HttpResponse("All of this category of rooms are booked!! ")



def add_emp(request):
    if request.method == "POST":
        form = EmployeeForm(request.POST)
        if form.is_valid():
            emp = form.save()
            # post.author = request.user
            # post.published_date = timezone.now()
            # post.save()
            return HttpResponseRedirect(reverse('index'))
    else:
        form = EmployeeForm()
    return render(request, 'hotels/add_emp.html', {'form': form})
def identify(request):
    return render(request,'hotels/employee.html')

def add_photos(request):
	emp_list = Employee.objects.all()
	return render(request, 'hotels/add_photos.html', {'emp_list': emp_list})