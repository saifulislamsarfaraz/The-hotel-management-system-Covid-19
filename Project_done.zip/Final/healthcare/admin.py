from django.contrib import admin
from .models import Appointment
from .models import TakeAppointment
from .models import Doctor
#Register your models here.

admin.site.register(Appointment)
admin.site.register(TakeAppointment)
admin.site.register(Doctor)



# Register your models here.
