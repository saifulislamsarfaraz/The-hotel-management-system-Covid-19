from django.contrib import admin
from .models import Appointment
from .models import TakeAppointment
#Register your models here.

admin.site.register(Appointment)
admin.site.register(TakeAppointment)



# Register your models here.
