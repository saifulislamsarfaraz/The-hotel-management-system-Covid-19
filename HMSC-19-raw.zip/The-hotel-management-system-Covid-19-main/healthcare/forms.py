from django.contrib.auth.models import User
from django import forms
from .models import Appointment
from django.forms.widgets import DateInput

class AppointmentForm(forms.ModelForm):

    class Meta:
        model = Appointment
        fields = ['user', 'full_name','image','location','start_time','end_time','qualification_name','institute_name','hospital_name','department','created_at']