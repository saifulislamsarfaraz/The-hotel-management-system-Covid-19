from django.shortcuts import render
from .models import Appointment
from hotel import urls
from employeeRec import urls
from .forms import BookForm,AppointmentForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from hotel.decorators import unauthenticated_user, allowed_users, admin_only

@allowed_users(allowed_roles=['doctor'])
def apoinment(request):
    form = AppointmentForm()
    if(request.method=='POST'):
        form = AppointmentForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request,'healthcare/healthHome.html')
    context = {'form':form}
    return render(request,'healthcare/appointment.html',context)


def takeappoinment(request):

    form = BookForm()
    if(request.method=='POST'):
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request,'healthcare/healthHome.html')
    context = {'form':form}
    return render(request,'healthcare/appointment_form.html',context)

def healthHome(request):
    return render(request,'healthcare/healthHome.html')
    