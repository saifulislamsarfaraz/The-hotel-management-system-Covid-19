from unicodedata import name
from django.urls import path
from .import views

urlpatterns = [
    path('register/',views.registerPage, name="register"),
    path('login/',views.loginPage,name='login'),
    path('login/Login.html',views.loginPage,name='alLog'),
    path('login/Register.html',views.registerPage,name='alReg'),
]
