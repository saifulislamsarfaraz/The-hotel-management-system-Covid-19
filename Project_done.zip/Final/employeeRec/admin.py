from django.contrib import admin
from .models import Employee, Detected

# Register your models here.

admin.site.register(Employee)
admin.site.register(Detected)