Assalamu alikum sir,

To run this porgram you need:

python 3.6.0
django 4.0.2
Redis  3.2.100 
Download link: https://github.com/MicrosoftArchive/redis/releases/download/win-3.2.100/Redis-x64-3.2.100.msi

Command line:
Open command prompt go the HMS file directory execute command line:

pip install django-redis==4.12.1
pip install django-redis-cache==3.0.0
python manage.py runserver


github link for this project:
https://github.com/saifulislamsarfaraz/The-hotel-management-system-Covid-19.git

source code for face componanet 
https://github.com/ageitgey/face_recognition/blob/master/examples/face_recognition_knn.py


Thanks for visited 

New Features
1.Login
2.Signup
3.Password Reset
4.Vacination status
5.View all Hotel Rooms Information
6.Search Room Category
7.View Room
8.Contact
9.Health Care
10.Appointments
11.MakeAppointments
12.Add employee
14.add employee photos
15.Employee Detacted
16.User Authentications Permissions
17.Booking Rooms  



Final Features:
18.Face attendance 
19.search employee
20.search attendance list
21.traind model
22.show booking list
23.delete booking list
24.show booking apoinment list
25.show doctors
