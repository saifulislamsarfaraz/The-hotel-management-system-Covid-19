from distutils.command.upload import upload
from email.mime import image
import numbers
from ssl import Options
from tabnanny import check
from unicodedata import category
from django.db import models
from django.conf import settings

# Create your models here.


class Room(models.Model):
    
    ROOM_CATEGORIES = (
        ('YAC','Ac'),
        ('NAC','Non-Ac'),
        ('DEL','Deluex'),
        ('KIN','King'),
        ('QUE', 'Queen'),
        ('STDIOU', 'Stduio'),
        ('HTR', 'Hollywood-Twin-Room'),
        ('ES', 'Executive'),
        ('MS', 'MiniSuite'),
        ('PS', 'PresidentialSuite'),
        ('AP', 'Apartments'),
        ('CR', 'ConnectingRooms'),
        ('MR', 'MurphyRooms'),
        ('AR', 'Accessible'),
        ('CN', 'Cabana'),
        ('ADR', 'AdjoiningRoom'),
        ('VIL', 'Villa'),
        ('EF', 'ExecutiveRoom'),
        ('NSM', 'Non-SmokingRoom'),

    )
    number = models.IntegerField()
    category = models.CharField(max_length=6,choices=ROOM_CATEGORIES)
    beds = models.IntegerField()
    desc = models.TextField()
    capacity = models.IntegerField()
    image = models.CharField(max_length=400)

    def __str__(self):
        return self.category
    
class VacinationStatus(models.Model):
    vacinationCirtificateNum = models.CharField(max_length=12)
    totalDose = models.IntegerField()
    covidTest = models.CharField(max_length=10)
    username = models.CharField(max_length=10)

    
class BookingRoom(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    check_in = models.DateTimeField()
    check_out = models.DateTimeField()

sex_choice = (
    ('Male', 'Male'),
    ('Female', 'Female')
)

class Employee(models.Model):
	id = models.CharField(primary_key=True, max_length=60)
	name = models.CharField(max_length=50)
	contact_number = models.CharField(max_length=50)
	date_of_birth = models.CharField(max_length=50)
	date_of_joining = models.CharField(max_length=50)
	department = models.CharField(max_length=50)
	designation = models.CharField(max_length=50)
	gender = models.CharField(max_length=50, choices=sex_choice, default='Male')
	team = models.CharField(max_length=50)

class UserProfiles(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    FirstName = models.CharField(max_length=50)
    LastName = models.CharField(max_length=50)
    DateofBirth = models.DateField()
    gender = models.CharField(max_length=50, choices=sex_choice, default='Male')
    
	
    

class EmployeeDetected(models.Model):
    emp_id = models.ForeignKey(Employee, on_delete=models.CASCADE, null=True)

