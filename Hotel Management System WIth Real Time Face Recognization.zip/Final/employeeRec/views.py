from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.utils import timezone
from .facerec.click_photos import click
from .facerec.train_faces import trainer
from .facerec.identify_faces import identify_faces
from .models import Employee, Detected
from .forms import EmployeeForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from hotel.decorators import unauthenticated_user, allowed_users, admin_only
import cv2
import pickle
import face_recognition
import datetime
from hotel import views

@login_required(login_url='login')
#@allowed_users(allowed_roles=['employee'])
def index(request):
    return render(request, 'employeeRec/index.html')

@login_required(login_url='login')
def add_photos(request):
	emp_list = Employee.objects.all()
	return render(request, 'employeeRec/add_photos.html', {'emp_list': emp_list})

@login_required(login_url='login')
def click_photos(request, emp_id):
	cam = cv2.VideoCapture(0)
	emp = get_object_or_404(Employee, id=emp_id)
	click(emp.name, emp.id, cam)
	return HttpResponseRedirect(reverse('add_photos'))

@login_required(login_url='login')
def train_model(request):
	trainer()
	return HttpResponseRedirect(reverse('index'))

@login_required(login_url='login')
def detected(request):
	if request.method == 'GET':
		date_formatted = datetime.datetime.today().date()
		date = request.GET.get('search_box', None)
		if date is not None:
			date_formatted = datetime.datetime.strptime(date, "%Y-%m-%d").date()
		
	det_list = Detected.objects.filter(time_stamp__date=date_formatted).order_by('time_stamp').reverse()
	return render(request, 'employeeRec/detected.html', {'det_list': det_list, 'date': date_formatted})

@login_required(login_url='login')
def identify(request):
	video_capture = cv2.VideoCapture(0)
	identify_faces(video_capture)
	return HttpResponseRedirect(reverse('index'))
    

@login_required(login_url='login')
#@allowed_users(allowed_roles=['admin'])
def add_emp(request):
    if request.method == "POST":
        form = EmployeeForm(request.POST)
        if form.is_valid():
            emp = form.save()
            return HttpResponseRedirect(reverse('index'))
    else:
        form = EmployeeForm()
    return render(request, 'employeeRec/add_emp.html', {'form': form})




