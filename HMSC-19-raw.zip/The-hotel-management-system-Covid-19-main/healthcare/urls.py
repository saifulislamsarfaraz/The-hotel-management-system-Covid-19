from django.urls import path


from .import views
from hotel.views import home



urlpatterns = [
    
    path('apointments/',views.apoinment,name='apointments'),

  
]
