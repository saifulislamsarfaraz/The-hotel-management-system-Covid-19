from datetime import timezone
from distutils.command.upload import upload
from email.mime import image
import numbers
from pyexpat import model
from ssl import Options
from tabnanny import check
from typing_extensions import Self
from unicodedata import category, name
from django.db import models
from django.conf import settings

from django.urls import reverse_lazy

# Create your models here.

class RoomCategory(models.Model):
    category = models.CharField(max_length=50)
    rate = models.FloatField()

    def __str__(self):
        return self.category

class Room(models.Model):
    
    ROOM_CATEGORIES = (
        ('YAC','Ac'),
        ('NAC','Non-Ac'),
        ('DEL','Deluex'),
        ('KIN','King'),
        ('QUE', 'Queen'),
        ('STDIOU', 'Stduio'),
        ('HTR', 'Hollywood-Twin-Room'),
        ('ES', 'Executive'),
        ('MS', 'MiniSuite'),
        ('PS', 'PresidentialSuite'),
        ('AP', 'Apartments'),
        ('CR', 'ConnectingRooms'),
        ('MR', 'MurphyRooms'),
        ('AR', 'Accessible'),
        ('CN', 'Cabana'),
        ('ADR', 'AdjoiningRoom'),
        ('VIL', 'Villa'),
        ('EF', 'ExecutiveRoom'),
        ('NSM', 'Non-SmokingRoom'),

    )
    number = models.IntegerField()
    category = models.CharField(max_length=6,choices=ROOM_CATEGORIES)
    beds = models.IntegerField()
    desc = models.TextField()
    capacity = models.IntegerField()
    image = models.CharField(max_length=400)

    def __str__(self):
        return f'{self.number}. {self.category} with {self.beds} beds for {self.capacity} people'   



    
class BookingRoom(models.Model):

    user = models.ForeignKey(settings.AUTH_USER_MODEL,
                             on_delete=models.CASCADE)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    check_in = models.DateTimeField()
    check_out = models.DateTimeField()
   

    def __str__(self):
        return f'From = {self.check_in.strftime("%d-%b-%Y %H:%M")} To = {self.check_out.strftime("%d-%b-%Y %H:%M")}'


sex_choice = (
    ('Male', 'Male'),
    ('Female', 'Female')
)


class VacinationStatus(models.Model):
    username = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    vacinationCirtificateNum = models.CharField(max_length=12)
    totalDose = models.IntegerField()
    covidTest = models.CharField(max_length=10)
    username = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)

class UserProfiles(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    FirstName = models.CharField(max_length=50)
    LastName = models.CharField(max_length=50)
    DateofBirth = models.DateField()
    gender = models.CharField(max_length=50, choices=sex_choice, default='Male')

	
class ContactUs(models.Model):
    name = models.CharField(max_length=15)
    email = models.CharField(max_length=30)
    phone = models.CharField(max_length=11)
    message = models.CharField(max_length=200) 


