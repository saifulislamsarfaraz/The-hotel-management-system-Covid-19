# The-hotel-management-system-Covid-19
# login page
![login](https://user-images.githubusercontent.com/62655613/154833737-3df7d8a8-8eca-461a-98ae-9306bf75d362.png)
# Register page
![Register](https://user-images.githubusercontent.com/62655613/154833806-ff7753eb-5873-4521-9e68-b73409f7ea8b.png)
