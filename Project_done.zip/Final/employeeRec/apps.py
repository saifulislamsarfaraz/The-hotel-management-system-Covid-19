from django.apps import AppConfig


class EmployeerecConfig(AppConfig):
    name = 'employeeRec'
