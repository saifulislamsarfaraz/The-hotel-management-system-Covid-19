from atexit import register
from dataclasses import fields
from random import choices
from tkinter.tix import Form
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms




class CreateUserForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username','email','password1','password2'] 


class AvailabilityForm(forms.Form):
    ROOM_CATEGORIES = (
        ('YAC','Ac'),
        ('NAC','Non-Ac'),
        ('DEL','Deluex'),
        ('KIN','King'),
        ('QUE', 'Queen'),
        ('STDIOU', 'Stduio'),
        ('HTR', 'Hollywood-Twin-Room'),
        ('ES', 'Executive'),
        ('MS', 'MiniSuite'),
        ('PS', 'PresidentialSuite'),
        ('AP', 'Apartments'),
        ('CR', 'ConnectingRooms'),
        ('MR', 'MurphyRooms'),
        ('AR', 'Accessible'),
        ('CN', 'Cabana'),
        ('ADR', 'AdjoiningRoom'),
        ('VIL', 'Villa'),
        ('EF', 'ExecutiveRoom'),
        ('NSM', 'Non-SmokingRoom'),

    )
    room_category = forms.ChoiceField(choices=ROOM_CATEGORIES,required=True)
    check_in = forms.DateTimeField(required=True, input_formats=["%Y-%m-%dT%H:%M", ])
    check_out = forms.DateTimeField(required=True, input_formats=["%Y-%m-%dT%H:%M", ])

from .models import Employee
from .models import VacinationStatus
from .models import ContactUs
class EmployeeForm(forms.ModelForm):

    class Meta:
        model = Employee
        fields = ('id', 'name','contact_number','date_of_birth','date_of_joining','department','designation','gender','team')

class ContactForm(forms.ModelForm):

    class Meta:
        model = ContactUs
        fields = ('name','email','phone','subject','message')

class VacinationsStatusForm(forms.ModelForm):
    class Meta:
        model = VacinationStatus
        fields = ('username','vacinationCirtificateNum','totalDose','covidTest')