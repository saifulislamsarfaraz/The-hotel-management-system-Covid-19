from django.contrib import admin
from .models import Room
from .models import VacinationStatus
from .models import BookingRoom
from .models import Employee
from .models import EmployeeDetected
from .models import UserProfiles
#Register your models here.

admin.site.register(Room)
admin.site.register(VacinationStatus)
admin.site.register(BookingRoom)
admin.site.register(Employee)
admin.site.register(EmployeeDetected)
admin.site.register(UserProfiles)

