from django.shortcuts import render
from .models import Appointment
from hotel import urls
from employeeRec import urls

def apoinment(request):
    return render(request,'healthcare/appointment.html')

def healthHome(request):
    return render(request,'healthcare/healthHome.html')