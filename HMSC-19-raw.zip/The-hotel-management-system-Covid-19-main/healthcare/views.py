from django.shortcuts import render
from .models import Appointment

def apoinment(request):
    return render(request,'healthcare/appointment.html')

    