from unicodedata import category
from django.db import models

# Create your models here.
class Room(models.Model):
    
    ROOM_CATEGORIES = (
        ('YAC','AC'),
        ('NAC','NON-AC'),
    )
    number = models.IntegerField()
    category = models.CharField(max_length=3,choices=ROOM_CATEGORIES)
    bads = models.IntegerField()
    capacity = models.IntegerField()
    
    def __str__(self) -> str:
        return super().__str__(f'{self.number}.{self.category} with {self.bads} for {self.capacity} people')
 

